applyPatch('20200413-dldt-disable-unused-targets.patch')
applyPatch('20200413-dldt-fix-binaries-location.patch')
applyPatch('20200413-dldt-pdb.patch')
applyPatch('20200604-dldt-disable-multidevice.patch')
