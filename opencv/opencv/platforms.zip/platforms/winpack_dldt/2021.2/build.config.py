os.environ['CI_BUILD_NUMBER'] = '2021.2.0-opencv_winpack_dldt'

cmake_vars['ENABLE_V10_SERIALIZE'] = 'ON'
