applyPatch('20201217-dldt-disable-unused-targets.patch')
applyPatch('20200413-dldt-pdb.patch')
applyPatch('20200604-dldt-disable-multidevice.patch')
applyPatch('20201218-dldt-vs-version.patch')
