ABIs = [
    ABI("2", "armeabi-v7a", None, 24, cmake_vars=dict(ANDROID_ABI='armeabi-v7a with NEON')),
    ABI("3", "arm64-v8a",   None, 24),
    ABI("5", "x86_64",      None, 24),
    ABI("4", "x86",         None, 24),
]
