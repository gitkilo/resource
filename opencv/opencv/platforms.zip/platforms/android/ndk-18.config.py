ABIs = [
    ABI("2", "armeabi-v7a", None, cmake_vars=dict(ANDROID_ABI='armeabi-v7a with NEON')),
    ABI("3", "arm64-v8a",   None),
    ABI("5", "x86_64",      None),
    ABI("4", "x86",         None),
]
