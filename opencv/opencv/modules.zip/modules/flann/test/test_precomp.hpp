#ifndef OPENCV_TEST_PRECOMP_HPP
#define OPENCV_TEST_PRECOMP_HPP

#include "opencv2/ts.hpp"
#include "opencv2/flann.hpp"

#endif
