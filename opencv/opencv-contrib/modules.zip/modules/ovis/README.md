OVIS Module
===========

allows you to render 3D data using the OGRE 3D engine and obtain the rendering as cv::Mat.
