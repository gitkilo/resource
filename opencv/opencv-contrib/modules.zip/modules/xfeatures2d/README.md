Extra 2D Features Framework
===========================

1. Experimental 2D feature algorithms
2. Non-free 2D feature algorithms

Extra 2D Features Framework containing experimental and non-free 2D feature detector/descriptor algorithms:
 SURF, BRIEF, Censure, Freak, LUCID, Daisy, BEBLID, Self-similar.
