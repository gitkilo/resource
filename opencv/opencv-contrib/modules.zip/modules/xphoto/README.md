Additional photo processing algorithms
======================================

1. Color balance
2. Denoising
3. Inpainting

