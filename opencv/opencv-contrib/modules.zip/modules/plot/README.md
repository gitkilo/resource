Plot Module
===========

Created by Nuno Moutinho

This Plot module allows you to easily plot data in 1D or 2D. You can change the size of the window, the limits of the axis and the colors of each element. You can also show in real time the plot you are building or save the plot as an image (png).
