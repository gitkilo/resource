Plot - Module to Plot Data
==========================

.. highlight:: cpp

This Plot module allows you to easily plot data in 1D or 2D. You can change the size of the window, the limits of the axis and the colors of each element.
