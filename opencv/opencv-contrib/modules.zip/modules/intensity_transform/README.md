Intensity Transformations
========================

This module contains some of the intensity transformation methods used to adjust the constrast of an image. The methods in the module include autoscaling, gamma correction, log transformations, and contrast stretching.