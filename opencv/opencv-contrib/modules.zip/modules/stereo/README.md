Stereo Correspondence with different descriptors
================================================

Stereo matching done with different descriptors: Census / CS-Census / MCT / BRIEF / MV.

Quasi Dense Stereo
======================

Quasi Dense Stereo is method for performing dense stereo matching.
The code uses pyramidal Lucas-Kanade with Shi-Tomasi features to get the initial seed correspondences.
Then these seeds are propagated by using mentioned growing scheme.
