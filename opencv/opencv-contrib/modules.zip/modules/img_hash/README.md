Image Hashing algorithms
========================

This module is intended to port the algorithms from PHash library and implement other image hash
algorithm do not exist in PHash library yet.
