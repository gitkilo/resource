Saliency API, Where to Focus in a Scene
=======================================

The purpose of this module is to create, group and make available to the users, different saliency algorithms, belonging to different categories. Saliency API -- Where humans would look in a scene. Has routines for static, motion and "objectness" saliency.

